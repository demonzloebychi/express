const csirSwiper = new Swiper('.csir-swiper', {
  // Navigation arrows
  navigation: {
    nextEl: '.csir-swiper-button-next',
    prevEl: '.csir-swiper-button-prev',
  },
   spaceBetween: 20,


});


