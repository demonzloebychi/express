//Вырезано из общего файла main.js и добавлено в отдельный файл, подключено только к главной странице сайта index.html

let typed = new Typed('#typed', {
  typeSpeed: 200,
  backSpeed: 100,
  startDelay: 3800,
  loop: false,
  stringsElement: '#typed-strings'
});
